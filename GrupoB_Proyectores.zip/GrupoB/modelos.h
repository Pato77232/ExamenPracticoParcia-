#ifndef MODELOS_H
#define MODELOS_H

#include <string>
using namespace std;

// ============================================================
//  CONSTANTE: límite de horas de lámpara (regla Grupo B)
//  Antes de reservar se verifica que la lámpara no supere
//  este límite. Si lo supera, el proyector pasa a mantenimiento
//  automáticamente y NO puede ser reservado.
// ============================================================
const int LIMITE_HORAS_LAMPARA = 2000;

// ============================================================
//  ENUM: Estado del proyector
// ============================================================
enum EstadoProyector {
    DISPONIBLE,
    PRESTADO,
    MANTENIMIENTO
};

// Convierte el enum a texto legible en consola
string estadoATexto(EstadoProyector e);

// ============================================================
//  CLASE: Proyector (modelo principal de datos)
//  Representa cada proyector físico de la facultad.
// ============================================================
class Proyector {
public:
    string  codigo;          // Identificador único: PRO001, PRO002...
    string  marca;           // Epson, BenQ, ViewSonic...
    string  aulaBase;        // Aula donde normalmente reside
    int     horasLampara;    // Horas de uso acumuladas de la lámpara
    EstadoProyector estado;  // Disponible / Prestado / Mantenimiento

    Proyector();
    Proyector(string cod, string mar, string aula,
              int horas, EstadoProyector est);

    void mostrar() const;
};

// ============================================================
//  CLASE: Reserva (registro de una reserva activa)
//  Guarda quién tiene reservado cada proyector y desde cuándo.
// ============================================================
class Reserva {
public:
    string codigoProyector;  // FK al proyector
    string docente;          // Nombre del docente que reserva
    string fecha;            // Fecha de la reserva (texto simple)
    string horaInicio;       // Hora de inicio estimada

    Reserva();
    Reserva(string codProy, string doc, string fec, string hora);

    void mostrar() const;
};

// ============================================================
//  CLASE: Solicitud (petición en espera — usada en la Cola)
//  Cuando un proyector ya está reservado, la nueva petición
//  queda en cola de espera con esta estructura.
// ============================================================
class Solicitud {
public:
    string codigoProyector;  // Proyector solicitado
    string docente;          // Docente que espera
    string motivo;           // Razón de la solicitud

    Solicitud();
    Solicitud(string codProy, string doc, string mot);

    void mostrar() const;
};

// ============================================================
//  CLASE: Accion (registro del historial — usada en Lista Doble)
//  Cada operación importante queda registrada aquí para poder
//  navegar el historial hacia adelante y hacia atrás.
// ============================================================
class Accion {
public:
    string descripcion;  // Qué se hizo
    string usuario;      // Quién lo hizo
    string momento;      // Cuándo (fecha/hora en texto)

    Accion();
    Accion(string desc, string usr, string mom);

    void mostrar() const;
};

// ============================================================
//  CLASE: Expositor (usado en lista circular de turnos)
//  En eventos con varios expositores, se rotan en ciclo.
// ============================================================
class Expositor {
public:
    string nombre;
    string tema;

    Expositor();
    Expositor(string nom, string tem);

    void mostrar() const;
};

#endif
