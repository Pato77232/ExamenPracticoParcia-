#ifndef ESTRUCTURAS_H
#define ESTRUCTURAS_H

#include "modelos.h"
#include <string>
using namespace std;

// ============================================================
//  NODO SIMPLE — para Lista simplemente enlazada
// ============================================================
struct NodoSimple {
    Reserva dato;
    NodoSimple* siguiente;
    NodoSimple(Reserva r) : dato(r), siguiente(nullptr) {}
};

// ============================================================
//  NODO DOBLE — para Lista doblemente enlazada (historial)
// ============================================================
struct NodoDoble {
    Accion dato;
    NodoDoble* anterior;
    NodoDoble* siguiente;
    NodoDoble(Accion a) : dato(a), anterior(nullptr), siguiente(nullptr) {}
};

// ============================================================
//  NODO COLA — para Cola de solicitudes en espera
// ============================================================
struct NodoCola {
    Solicitud dato;
    NodoCola* siguiente;
    NodoCola(Solicitud s) : dato(s), siguiente(nullptr) {}
};

// ============================================================
//  NODO PILA — para Pila de acciones reversibles
// ============================================================
struct NodoPila {
    string descripcionAccion;  // descripción de lo que se puede deshacer
    string codigoProyector;    // proyector afectado
    EstadoProyector estadoAnterior;  // estado al que volver
    NodoPila* siguiente;
    NodoPila(string desc, string cod, EstadoProyector est)
        : descripcionAccion(desc), codigoProyector(cod),
          estadoAnterior(est), siguiente(nullptr) {}
};

// ============================================================
//  NODO CIRCULAR — para Lista circular de expositores/turnos
// ============================================================
struct NodoCircular {
    Expositor dato;
    NodoCircular* siguiente;
    NodoCircular(Expositor e) : dato(e), siguiente(nullptr) {}
};

// ============================================================
//  ESTRUCTURA 1: Lista Secuencial (arreglo) — Inventario
//  Almacena todos los proyectores registrados.
//  Se eligió arreglo porque el inventario tiene tamaño
//  conocido y requiere acceso directo por índice para buscar,
//  modificar y eliminar de forma eficiente.
// ============================================================
class ListaInventario {
private:
    static const int CAPACIDAD = 50;
    Proyector datos[CAPACIDAD];
    int cantidad;

public:
    ListaInventario();

    bool insertar(Proyector p);
    int  buscarIndice(const string& codigo) const;
    Proyector* buscar(const string& codigo);
    bool modificarEstado(const string& codigo, EstadoProyector nuevoEstado);
    bool eliminar(const string& codigo);
    void mostrarTodos() const;
    int  getCantidad() const;
    Proyector* getProyector(int idx);  // acceso directo por índice
};

// ============================================================
//  ESTRUCTURA 2: Lista Simplemente Enlazada — Reservas activas
//  Almacena las reservas vigentes (dinámicas, crecen sin límite).
//  Lista enlazada porque las reservas se crean y eliminan
//  constantemente y no tienen tamaño fijo previsible.
// ============================================================
class ListaReservas {
private:
    NodoSimple* cabeza;
    int         cantidad;

public:
    ListaReservas();
    ~ListaReservas();

    void insertar(Reserva r);
    bool eliminar(const string& codigoProyector);
    NodoSimple* buscar(const string& codigoProyector) const;
    void mostrarTodas() const;
    bool estaReservado(const string& codigoProyector) const;
    int  getCantidad() const;
};

// ============================================================
//  ESTRUCTURA 3: Lista Doblemente Enlazada — Historial
//  Registra cada acción realizada en el sistema.
//  Lista doble porque el historial necesita navegación
//  bidireccional: ver las acciones más recientes o retroceder
//  para revisar operaciones anteriores.
// ============================================================
class ListaHistorial {
private:
    NodoDoble* cabeza;
    NodoDoble* cola;
    NodoDoble* actual;   // puntero de navegación
    int        cantidad;

public:
    ListaHistorial();
    ~ListaHistorial();

    void insertarAlFinal(Accion a);
    void navegarAdelante();
    void navegarAtras();
    void mostrarTodo() const;
    void mostrarActual() const;
    int  getCantidad() const;
};

// ============================================================
//  ESTRUCTURA 4: Cola (FIFO) — Solicitudes en espera
//  Cuando un proyector está ocupado, las peticiones esperan
//  en orden de llegada. FIFO es justo: el primero en pedir
//  es el primero en ser atendido cuando el proyector queda libre.
// ============================================================
class ColaSolicitudes {
private:
    NodoCola* frente;
    NodoCola* final_;
    int       cantidad;

public:
    ColaSolicitudes();
    ~ColaSolicitudes();

    void encolar(Solicitud s);
    bool desencolar(Solicitud& salidaSolicitud);
    void verFrente() const;
    void listarTodas() const;
    bool estaVacia() const;
    int  getCantidad() const;
};

// ============================================================
//  ESTRUCTURA 5: Pila (LIFO) — Deshacer última acción
//  Guarda cambios de estado para poder revertirlos.
//  La pila es perfecta porque "deshacer" siempre revierte
//  la ÚLTIMA acción realizada, que es exactamente LIFO.
// ============================================================
class PilaDeshacer {
private:
    NodoPila* tope;
    int       cantidad;

public:
    PilaDeshacer();
    ~PilaDeshacer();

    void apilar(string descripcion, string codProyector,
                EstadoProyector estadoAnterior);
    bool desapilar(string& descSalida, string& codSalida,
                   EstadoProyector& estadoSalida);
    void verTope() const;
    bool estaVacia() const;
    int  getCantidad() const;
};

// ============================================================
//  ESTRUCTURA 6: Lista Circular — Turnos de expositores
//  En eventos con varios expositores, el turno rota en ciclo
//  indefinidamente. La lista circular es la única estructura
//  que modela este comportamiento de forma natural porque
//  el último nodo apunta de vuelta al primero.
// ============================================================
class ListaCircularTurnos {
private:
    NodoCircular* actual;
    int           cantidad;

public:
    ListaCircularTurnos();
    ~ListaCircularTurnos();

    void insertar(Expositor e);
    void avanzarTurno();
    void eliminarActual();
    void mostrarRonda() const;
    void mostrarActual() const;
    bool estaVacia() const;
    int  getCantidad() const;
};

#endif
