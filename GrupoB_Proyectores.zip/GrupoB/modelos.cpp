#include "modelos.h"
#include <iostream>
using namespace std;

// ── EstadoProyector → texto ──────────────────────────────────────────────
string estadoATexto(EstadoProyector e) {
    switch (e) {
        case DISPONIBLE:    return "Disponible";
        case PRESTADO:      return "Prestado";
        case MANTENIMIENTO: return "Mantenimiento";
        default:            return "Desconocido";
    }
}

// ── Proyector ────────────────────────────────────────────────────────────
Proyector::Proyector()
    : codigo(""), marca(""), aulaBase(""),
      horasLampara(0), estado(DISPONIBLE) {}

Proyector::Proyector(string cod, string mar, string aula,
                     int horas, EstadoProyector est)
    : codigo(cod), marca(mar), aulaBase(aula),
      horasLampara(horas), estado(est) {}

void Proyector::mostrar() const {
    cout << "  Codigo     : " << codigo << "\n"
         << "  Marca      : " << marca  << "\n"
         << "  Aula base  : " << aulaBase << "\n"
         << "  Horas lamp.: " << horasLampara << " h"
         << (horasLampara >= LIMITE_HORAS_LAMPARA ? "  [LIMITE ALCANZADO]" : "") << "\n"
         << "  Estado     : " << estadoATexto(estado) << "\n";
}

// ── Reserva ──────────────────────────────────────────────────────────────
Reserva::Reserva()
    : codigoProyector(""), docente(""), fecha(""), horaInicio("") {}

Reserva::Reserva(string codProy, string doc, string fec, string hora)
    : codigoProyector(codProy), docente(doc), fecha(fec), horaInicio(hora) {}

void Reserva::mostrar() const {
    cout << "  Proyector  : " << codigoProyector << "\n"
         << "  Docente    : " << docente << "\n"
         << "  Fecha      : " << fecha   << "\n"
         << "  Hora inicio: " << horaInicio << "\n";
}

// ── Solicitud ────────────────────────────────────────────────────────────
Solicitud::Solicitud()
    : codigoProyector(""), docente(""), motivo("") {}

Solicitud::Solicitud(string codProy, string doc, string mot)
    : codigoProyector(codProy), docente(doc), motivo(mot) {}

void Solicitud::mostrar() const {
    cout << "  Proyector  : " << codigoProyector << "\n"
         << "  Docente    : " << docente << "\n"
         << "  Motivo     : " << motivo  << "\n";
}

// ── Accion ───────────────────────────────────────────────────────────────
Accion::Accion()
    : descripcion(""), usuario(""), momento("") {}

Accion::Accion(string desc, string usr, string mom)
    : descripcion(desc), usuario(usr), momento(mom) {}

void Accion::mostrar() const {
    cout << "  [" << momento << "] " << usuario
         << " -> " << descripcion << "\n";
}

// ── Expositor ────────────────────────────────────────────────────────────
Expositor::Expositor()
    : nombre(""), tema("") {}

Expositor::Expositor(string nom, string tem)
    : nombre(nom), tema(tem) {}

void Expositor::mostrar() const {
    cout << "  Expositor: " << nombre << "  |  Tema: " << tema << "\n";
}
