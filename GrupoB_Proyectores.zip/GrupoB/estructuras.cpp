#include "estructuras.h"
#include <iostream>
using namespace std;

// ════════════════════════════════════════════════════════════════
//  ESTRUCTURA 1: Lista Secuencial (Inventario de proyectores)
// ════════════════════════════════════════════════════════════════

ListaInventario::ListaInventario() : cantidad(0) {}

bool ListaInventario::insertar(Proyector p) {
    if (cantidad >= CAPACIDAD) {
        cout << "  [!] Inventario lleno. Capacidad maxima: " << CAPACIDAD << "\n";
        return false;
    }
    // Verificar duplicado
    if (buscarIndice(p.codigo) != -1) {
        cout << "  [!] Ya existe un proyector con codigo: " << p.codigo << "\n";
        return false;
    }
    datos[cantidad++] = p;
    return true;
}

int ListaInventario::buscarIndice(const string& codigo) const {
    for (int i = 0; i < cantidad; i++) {
        if (datos[i].codigo == codigo) return i;
    }
    return -1;
}

Proyector* ListaInventario::buscar(const string& codigo) {
    int idx = buscarIndice(codigo);
    if (idx == -1) return nullptr;
    return &datos[idx];
}

bool ListaInventario::modificarEstado(const string& codigo,
                                      EstadoProyector nuevoEstado) {
    int idx = buscarIndice(codigo);
    if (idx == -1) return false;
    datos[idx].estado = nuevoEstado;
    return true;
}

bool ListaInventario::eliminar(const string& codigo) {
    int idx = buscarIndice(codigo);
    if (idx == -1) return false;
    // Desplazar elementos hacia la izquierda
    for (int i = idx; i < cantidad - 1; i++) {
        datos[i] = datos[i + 1];
    }
    cantidad--;
    return true;
}

void ListaInventario::mostrarTodos() const {
    if (cantidad == 0) {
        cout << "  Inventario vacio.\n";
        return;
    }
    for (int i = 0; i < cantidad; i++) {
        cout << "  --- Proyector " << (i + 1) << " ---\n";
        datos[i].mostrar();
    }
}

int ListaInventario::getCantidad() const { return cantidad; }

Proyector* ListaInventario::getProyector(int idx) {
    if (idx < 0 || idx >= cantidad) return nullptr;
    return &datos[idx];
}

// ════════════════════════════════════════════════════════════════
//  ESTRUCTURA 2: Lista Simplemente Enlazada (Reservas activas)
// ════════════════════════════════════════════════════════════════

ListaReservas::ListaReservas() : cabeza(nullptr), cantidad(0) {}

ListaReservas::~ListaReservas() {
    NodoSimple* actual = cabeza;
    while (actual != nullptr) {
        NodoSimple* temp = actual->siguiente;
        delete actual;
        actual = temp;
    }
}

void ListaReservas::insertar(Reserva r) {
    NodoSimple* nuevo = new NodoSimple(r);
    // Insertar al inicio (O(1))
    nuevo->siguiente = cabeza;
    cabeza = nuevo;
    cantidad++;
}

bool ListaReservas::eliminar(const string& codigoProyector) {
    NodoSimple* actual   = cabeza;
    NodoSimple* anterior = nullptr;

    while (actual != nullptr) {
        if (actual->dato.codigoProyector == codigoProyector) {
            if (anterior == nullptr) {
                cabeza = actual->siguiente;   // era el primero
            } else {
                anterior->siguiente = actual->siguiente;
            }
            delete actual;
            cantidad--;
            return true;
        }
        anterior = actual;
        actual   = actual->siguiente;
    }
    return false;
}

NodoSimple* ListaReservas::buscar(const string& codigoProyector) const {
    NodoSimple* actual = cabeza;
    while (actual != nullptr) {
        if (actual->dato.codigoProyector == codigoProyector) return actual;
        actual = actual->siguiente;
    }
    return nullptr;
}

void ListaReservas::mostrarTodas() const {
    if (cabeza == nullptr) {
        cout << "  No hay reservas activas.\n";
        return;
    }
    NodoSimple* actual = cabeza;
    int i = 1;
    while (actual != nullptr) {
        cout << "  --- Reserva " << i++ << " ---\n";
        actual->dato.mostrar();
        actual = actual->siguiente;
    }
}

bool ListaReservas::estaReservado(const string& codigoProyector) const {
    return buscar(codigoProyector) != nullptr;
}

int ListaReservas::getCantidad() const { return cantidad; }

// ════════════════════════════════════════════════════════════════
//  ESTRUCTURA 3: Lista Doblemente Enlazada (Historial)
// ════════════════════════════════════════════════════════════════

ListaHistorial::ListaHistorial()
    : cabeza(nullptr), cola(nullptr), actual(nullptr), cantidad(0) {}

ListaHistorial::~ListaHistorial() {
    NodoDoble* n = cabeza;
    while (n != nullptr) {
        NodoDoble* temp = n->siguiente;
        delete n;
        n = temp;
    }
}

void ListaHistorial::insertarAlFinal(Accion a) {
    NodoDoble* nuevo = new NodoDoble(a);
    if (cola == nullptr) {
        cabeza = cola = actual = nuevo;
    } else {
        nuevo->anterior = cola;
        cola->siguiente = nuevo;
        cola    = nuevo;
        actual  = nuevo;   // el puntero de navegación apunta siempre al más reciente
    }
    cantidad++;
}

void ListaHistorial::navegarAdelante() {
    if (actual == nullptr || actual->siguiente == nullptr) {
        cout << "  [!] Ya estas en la accion mas reciente del historial.\n";
        return;
    }
    actual = actual->siguiente;
    cout << "  >> Avanzando al siguiente registro:\n";
    actual->dato.mostrar();
}

void ListaHistorial::navegarAtras() {
    if (actual == nullptr || actual->anterior == nullptr) {
        cout << "  [!] Ya estas en el primer registro del historial.\n";
        return;
    }
    actual = actual->anterior;
    cout << "  << Retrocediendo al registro anterior:\n";
    actual->dato.mostrar();
}

void ListaHistorial::mostrarTodo() const {
    if (cabeza == nullptr) {
        cout << "  Historial vacio.\n";
        return;
    }
    NodoDoble* n = cabeza;
    int i = 1;
    while (n != nullptr) {
        cout << "  " << i++ << ". ";
        n->dato.mostrar();
        n = n->siguiente;
    }
}

void ListaHistorial::mostrarActual() const {
    if (actual == nullptr) {
        cout << "  Historial vacio.\n";
        return;
    }
    cout << "  Registro actual: ";
    actual->dato.mostrar();
}

int ListaHistorial::getCantidad() const { return cantidad; }

// ════════════════════════════════════════════════════════════════
//  ESTRUCTURA 4: Cola FIFO (Solicitudes en espera)
// ════════════════════════════════════════════════════════════════

ColaSolicitudes::ColaSolicitudes()
    : frente(nullptr), final_(nullptr), cantidad(0) {}

ColaSolicitudes::~ColaSolicitudes() {
    NodoCola* actual = frente;
    while (actual != nullptr) {
        NodoCola* temp = actual->siguiente;
        delete actual;
        actual = temp;
    }
}

void ColaSolicitudes::encolar(Solicitud s) {
    NodoCola* nuevo = new NodoCola(s);
    if (final_ == nullptr) {
        frente = final_ = nuevo;
    } else {
        final_->siguiente = nuevo;
        final_ = nuevo;
    }
    cantidad++;
}

bool ColaSolicitudes::desencolar(Solicitud& salidaSolicitud) {
    if (frente == nullptr) return false;

    salidaSolicitud = frente->dato;
    NodoCola* temp  = frente;
    frente          = frente->siguiente;
    if (frente == nullptr) final_ = nullptr;
    delete temp;
    cantidad--;
    return true;
}

void ColaSolicitudes::verFrente() const {
    if (frente == nullptr) {
        cout << "  Cola de espera vacia.\n";
        return;
    }
    cout << "  Proxima solicitud en cola:\n";
    frente->dato.mostrar();
}

void ColaSolicitudes::listarTodas() const {
    if (frente == nullptr) {
        cout << "  No hay solicitudes en espera.\n";
        return;
    }
    NodoCola* actual = frente;
    int i = 1;
    while (actual != nullptr) {
        cout << "  [" << i++ << "] ";
        actual->dato.mostrar();
        actual = actual->siguiente;
    }
}

bool ColaSolicitudes::estaVacia() const { return frente == nullptr; }
int  ColaSolicitudes::getCantidad() const { return cantidad; }

// ════════════════════════════════════════════════════════════════
//  ESTRUCTURA 5: Pila LIFO (Deshacer última acción)
// ════════════════════════════════════════════════════════════════

PilaDeshacer::PilaDeshacer() : tope(nullptr), cantidad(0) {}

PilaDeshacer::~PilaDeshacer() {
    NodoPila* actual = tope;
    while (actual != nullptr) {
        NodoPila* temp = actual->siguiente;
        delete actual;
        actual = temp;
    }
}

void PilaDeshacer::apilar(string descripcion, string codProyector,
                           EstadoProyector estadoAnterior) {
    NodoPila* nuevo   = new NodoPila(descripcion, codProyector, estadoAnterior);
    nuevo->siguiente  = tope;
    tope              = nuevo;
    cantidad++;
}

bool PilaDeshacer::desapilar(string& descSalida, string& codSalida,
                              EstadoProyector& estadoSalida) {
    if (tope == nullptr) return false;

    descSalida   = tope->descripcionAccion;
    codSalida    = tope->codigoProyector;
    estadoSalida = tope->estadoAnterior;

    NodoPila* temp = tope;
    tope           = tope->siguiente;
    delete temp;
    cantidad--;
    return true;
}

void PilaDeshacer::verTope() const {
    if (tope == nullptr) {
        cout << "  Pila de deshacer vacia. No hay acciones reversibles.\n";
        return;
    }
    cout << "  Ultima accion reversible:\n"
         << "  Descripcion : " << tope->descripcionAccion << "\n"
         << "  Proyector   : " << tope->codigoProyector   << "\n"
         << "  Estado prev.: " << estadoATexto(tope->estadoAnterior) << "\n";
}

bool PilaDeshacer::estaVacia() const { return tope == nullptr; }
int  PilaDeshacer::getCantidad() const { return cantidad; }

// ════════════════════════════════════════════════════════════════
//  ESTRUCTURA 6: Lista Circular (Turnos de expositores en evento)
// ════════════════════════════════════════════════════════════════

ListaCircularTurnos::ListaCircularTurnos()
    : actual(nullptr), cantidad(0) {}

ListaCircularTurnos::~ListaCircularTurnos() {
    if (actual == nullptr) return;
    // Romper el ciclo antes de liberar
    NodoCircular* inicio = actual;
    NodoCircular* n      = actual->siguiente;
    while (n != inicio) {
        NodoCircular* temp = n->siguiente;
        delete n;
        n = temp;
    }
    delete inicio;
}

void ListaCircularTurnos::insertar(Expositor e) {
    NodoCircular* nuevo = new NodoCircular(e);
    if (actual == nullptr) {
        nuevo->siguiente = nuevo;   // apunta a sí mismo → forma el ciclo
        actual           = nuevo;
    } else {
        // Insertar después de 'actual' para mantener el ciclo
        nuevo->siguiente   = actual->siguiente;
        actual->siguiente  = nuevo;
    }
    cantidad++;
}

void ListaCircularTurnos::avanzarTurno() {
    if (actual == nullptr) {
        cout << "  No hay expositores registrados.\n";
        return;
    }
    actual = actual->siguiente;
    cout << "  Turno avanzado. Ahora le toca a:\n";
    actual->dato.mostrar();
}

void ListaCircularTurnos::eliminarActual() {
    if (actual == nullptr) {
        cout << "  No hay expositores en la ronda.\n";
        return;
    }
    if (cantidad == 1) {
        delete actual;
        actual   = nullptr;
        cantidad = 0;
        cout << "  Expositor eliminado. La ronda quedo vacia.\n";
        return;
    }
    // Buscar el nodo anterior al actual (necesario para mantener el ciclo)
    NodoCircular* anterior = actual;
    while (anterior->siguiente != actual) {
        anterior = anterior->siguiente;
    }
    anterior->siguiente = actual->siguiente;
    NodoCircular* temp  = actual;
    actual              = actual->siguiente;   // el turno pasa al siguiente
    delete temp;
    cantidad--;
    cout << "  Expositor eliminado. Siguiente turno:\n";
    actual->dato.mostrar();
}

void ListaCircularTurnos::mostrarRonda() const {
    if (actual == nullptr) {
        cout << "  Ronda vacia. No hay expositores.\n";
        return;
    }
    NodoCircular* inicio = actual;
    NodoCircular* n      = actual;
    int i = 1;
    do {
        cout << "  Turno " << i++ << (n == actual ? " [ACTUAL]" : "") << ":\n";
        n->dato.mostrar();
        n = n->siguiente;
    } while (n != inicio);
}

void ListaCircularTurnos::mostrarActual() const {
    if (actual == nullptr) {
        cout << "  No hay turno activo.\n";
        return;
    }
    cout << "  Turno actual:\n";
    actual->dato.mostrar();
}

bool ListaCircularTurnos::estaVacia() const { return actual == nullptr; }
int  ListaCircularTurnos::getCantidad() const { return cantidad; }
