// ============================================================
//  SmartCampus UTA — Grupo B
//  Sistema de Reserva y Rotacion de Proyectores
//  Asignatura: Estructura de Datos — C++17
//  Entorno: Visual Studio Code
//  Compilacion: g++ -std=c++17 main.cpp modelos.cpp estructuras.cpp -o app
// ============================================================

#include <iostream>
#include <string>
#include <limits>
#include "modelos.h"
#include "estructuras.h"
using namespace std;

// ── Variables globales del sistema ──────────────────────────────────────────
ListaInventario   inventario;
ListaReservas     reservas;
ListaHistorial    historial;
ColaSolicitudes   cola;
PilaDeshacer      pila;
ListaCircularTurnos turnos;

// ── Utilidades de consola ────────────────────────────────────────────────────
void limpiarBuffer() {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void pausar() {
    cout << "\n  Presiona Enter para continuar...";
    cin.get();
}

void separador() {
    cout << "  " << string(58, '-') << "\n";
}

void encabezado(const string& titulo) {
    cout << "\n  " << string(58, '=') << "\n";
    cout << "   " << titulo << "\n";
    cout << "  " << string(58, '=') << "\n";
}

// Registra una acción en el historial
void registrarAccion(const string& desc, const string& usuario) {
    historial.insertarAlFinal(Accion(desc, usuario, "2025-06-15 10:00"));
}

// ── Validar que un string no esté vacío ─────────────────────────────────────
string leerCadena(const string& prompt) {
    string val;
    do {
        cout << "  " << prompt;
        getline(cin, val);
        if (val.empty()) cout << "  [!] El campo no puede estar vacio.\n";
    } while (val.empty());
    return val;
}

int leerEntero(const string& prompt, int minimo = 0, int maximo = 99999) {
    int val;
    while (true) {
        cout << "  " << prompt;
        if (cin >> val && val >= minimo && val <= maximo) {
            limpiarBuffer();
            return val;
        }
        cout << "  [!] Valor invalido. Ingresa un numero entre "
             << minimo << " y " << maximo << ".\n";
        cin.clear();
        limpiarBuffer();
    }
}

// ════════════════════════════════════════════════════════════════
//  DATOS DE PRUEBA — cargados al inicio
// ════════════════════════════════════════════════════════════════
void cargarDatosPrueba() {
    // Inventario (lista secuencial)
    inventario.insertar(Proyector("PRO001", "Epson",     "Aula B201", 1500, DISPONIBLE));
    inventario.insertar(Proyector("PRO002", "BenQ",      "Aula A102", 2100, MANTENIMIENTO));
    inventario.insertar(Proyector("PRO003", "ViewSonic", "Aula C301",  800, PRESTADO));
    inventario.insertar(Proyector("PRO004", "Optoma",    "Aula D105",  400, DISPONIBLE));
    inventario.insertar(Proyector("PRO005", "Panasonic", "Aula E201", 1950, DISPONIBLE));

    // Reservas activas (lista simplemente enlazada)
    reservas.insertar(Reserva("PRO003", "Dr. Perez",    "2025-06-15", "08:00"));
    reservas.insertar(Reserva("PRO001", "Ing. Lopez",   "2025-06-15", "10:00"));

    // Historial (lista doblemente enlazada)
    historial.insertarAlFinal(Accion("Sistema iniciado",          "Admin",       "2025-06-15 07:00"));
    historial.insertarAlFinal(Accion("PRO003 reservado",           "Dr. Perez",  "2025-06-15 07:30"));
    historial.insertarAlFinal(Accion("PRO002 enviado a mantenimiento","Admin",   "2025-06-15 08:00"));
    historial.insertarAlFinal(Accion("PRO001 reservado",           "Ing. Lopez", "2025-06-15 09:00"));

    // Cola de espera (cola FIFO)
    cola.encolar(Solicitud("PRO001", "Msc. Ramos",  "Clase de Redes 10:00"));
    cola.encolar(Solicitud("PRO003", "Ing. Vargas", "Taller de BD 11:00"));

    // Pila de deshacer — guarda el estado anterior de PRO002
    pila.apilar("PRO002 enviado a mantenimiento", "PRO002", DISPONIBLE);

    // Turnos circulares (lista circular)
    turnos.insertar(Expositor("Dr. Caiza",    "Inteligencia Artificial"));
    turnos.insertar(Expositor("Ing. Moreta",  "Redes de Computadoras"));
    turnos.insertar(Expositor("Msc. Tisalema","Estructura de Datos"));

    cout << "  [OK] Datos de prueba cargados correctamente.\n";
}

// ════════════════════════════════════════════════════════════════
//  MÓDULO 1: Inventario
// ════════════════════════════════════════════════════════════════
void menuInventario() {
    int op;
    do {
        encabezado("MODULO 1 — INVENTARIO DE PROYECTORES");
        cout << "  1. Ver todos los proyectores\n";
        cout << "  2. Registrar nuevo proyector\n";
        cout << "  3. Buscar proyector por codigo\n";
        cout << "  4. Modificar estado de proyector\n";
        cout << "  5. Eliminar proyector\n";
        cout << "  0. Volver al menu principal\n";
        separador();
        op = leerEntero("Opcion: ", 0, 5);

        if (op == 1) {
            encabezado("LISTADO COMPLETO DE PROYECTORES");
            inventario.mostrarTodos();
            pausar();

        } else if (op == 2) {
            encabezado("REGISTRAR NUEVO PROYECTOR");
            limpiarBuffer();
            string cod   = leerCadena("Codigo (ej. PRO006): ");
            string marca = leerCadena("Marca: ");
            string aula  = leerCadena("Aula base: ");
            int horas    = leerEntero("Horas de lampara: ", 0, 9999);

            // Regla Grupo B: si supera el límite, no puede entrar como disponible
            EstadoProyector est = DISPONIBLE;
            if (horas >= LIMITE_HORAS_LAMPARA) {
                cout << "  [!] AVISO: lampara supera " << LIMITE_HORAS_LAMPARA
                     << " horas. El proyector se registra en MANTENIMIENTO.\n";
                est = MANTENIMIENTO;
            }

            if (inventario.insertar(Proyector(cod, marca, aula, horas, est))) {
                registrarAccion("Proyector " + cod + " registrado", "Admin");
                cout << "  [OK] Proyector registrado exitosamente.\n";
            }
            pausar();

        } else if (op == 3) {
            encabezado("BUSCAR PROYECTOR");
            limpiarBuffer();
            string cod = leerCadena("Codigo del proyector: ");
            Proyector* p = inventario.buscar(cod);
            if (p != nullptr) {
                p->mostrar();
            } else {
                cout << "  [!] No se encontro el proyector " << cod << "\n";
            }
            pausar();

        } else if (op == 4) {
            encabezado("MODIFICAR ESTADO");
            limpiarBuffer();
            string cod = leerCadena("Codigo del proyector: ");
            Proyector* p = inventario.buscar(cod);
            if (p == nullptr) {
                cout << "  [!] Proyector no encontrado.\n";
            } else {
                cout << "  Estado actual: " << estadoATexto(p->estado) << "\n";
                cout << "  Nuevo estado:\n";
                cout << "    1. Disponible\n  2. Prestado\n  3. Mantenimiento\n";
                int nEst = leerEntero("Opcion: ", 1, 3);

                EstadoProyector anterior = p->estado;
                EstadoProyector nuevo    = (nEst == 1) ? DISPONIBLE :
                                          (nEst == 2) ? PRESTADO : MANTENIMIENTO;

                // Guardar en pila antes de modificar (para poder deshacer)
                pila.apilar("Cambio de estado de " + cod, cod, anterior);

                inventario.modificarEstado(cod, nuevo);
                registrarAccion("Estado de " + cod + " cambiado a " +
                                estadoATexto(nuevo), "Admin");
                cout << "  [OK] Estado actualizado. Accion guardada en pila (puede deshacerse).\n";
            }
            pausar();

        } else if (op == 5) {
            encabezado("ELIMINAR PROYECTOR");
            limpiarBuffer();
            string cod = leerCadena("Codigo del proyector: ");
            // Verificar que no tenga reserva activa
            if (reservas.estaReservado(cod)) {
                cout << "  [!] No se puede eliminar: el proyector tiene una reserva activa.\n";
            } else if (inventario.eliminar(cod)) {
                registrarAccion("Proyector " + cod + " eliminado", "Admin");
                cout << "  [OK] Proyector eliminado del inventario.\n";
            } else {
                cout << "  [!] Proyector no encontrado.\n";
            }
            pausar();
        }

    } while (op != 0);
}

// ════════════════════════════════════════════════════════════════
//  MÓDULO 2: Reservas (Lista Simplemente Enlazada)
// ════════════════════════════════════════════════════════════════
void menuReservas() {
    int op;
    do {
        encabezado("MODULO 2 — RESERVAS ACTIVAS");
        cout << "  1. Ver todas las reservas activas\n";
        cout << "  2. Realizar nueva reserva\n";
        cout << "  3. Devolver proyector (eliminar reserva)\n";
        cout << "  0. Volver\n";
        separador();
        op = leerEntero("Opcion: ", 0, 3);

        if (op == 1) {
            encabezado("RESERVAS ACTIVAS");
            reservas.mostrarTodas();
            pausar();

        } else if (op == 2) {
            encabezado("NUEVA RESERVA");
            limpiarBuffer();
            string cod     = leerCadena("Codigo del proyector: ");
            Proyector* p   = inventario.buscar(cod);

            if (p == nullptr) {
                cout << "  [!] Proyector no encontrado en el inventario.\n";

            } else if (p->estado == MANTENIMIENTO) {
                cout << "  [!] El proyector esta en mantenimiento. No puede reservarse.\n";

            } else if (p->horasLampara >= LIMITE_HORAS_LAMPARA) {
                // Regla diferenciadora Grupo B
                cout << "  [!] REGLA GRUPO B: La lampara supera "
                     << LIMITE_HORAS_LAMPARA << " horas. Reserva denegada.\n";
                cout << "  El proyector debe ir a mantenimiento antes de usarse.\n";

            } else if (p->estado == PRESTADO || reservas.estaReservado(cod)) {
                // Proyector ocupado → encolar solicitud
                cout << "  [!] El proyector esta ocupado. La solicitud pasa a la cola de espera.\n";
                string docente = leerCadena("Nombre del docente: ");
                string motivo  = leerCadena("Motivo de la solicitud: ");
                cola.encolar(Solicitud(cod, docente, motivo));
                registrarAccion("Solicitud de " + docente + " encolada para " + cod,
                                docente);
                cout << "  [OK] Solicitud agregada a la cola. Posicion: "
                     << cola.getCantidad() << "\n";

            } else {
                // Disponible → reservar
                string docente = leerCadena("Nombre del docente: ");
                string fecha   = leerCadena("Fecha (YYYY-MM-DD): ");
                string hora    = leerCadena("Hora de inicio (HH:MM): ");
                reservas.insertar(Reserva(cod, docente, fecha, hora));
                inventario.modificarEstado(cod, PRESTADO);
                pila.apilar("Reserva de " + cod + " por " + docente, cod, DISPONIBLE);
                registrarAccion("Proyector " + cod + " reservado por " + docente, docente);
                cout << "  [OK] Reserva registrada exitosamente.\n";
            }
            pausar();

        } else if (op == 3) {
            encabezado("DEVOLUCION DE PROYECTOR");
            limpiarBuffer();
            string cod = leerCadena("Codigo del proyector a devolver: ");
            if (reservas.eliminar(cod)) {
                inventario.modificarEstado(cod, DISPONIBLE);
                registrarAccion("Proyector " + cod + " devuelto", "Admin");
                cout << "  [OK] Devolucion registrada. Proyector disponible.\n";

                // Si hay solicitudes en cola para ese proyector, atender la primera
                if (!cola.estaVacia()) {
                    cout << "\n  Hay solicitudes en cola. ";
                    cola.verFrente();
                    cout << "  Use el modulo de Cola para atenderla.\n";
                }
            } else {
                cout << "  [!] No se encontro reserva activa para ese proyector.\n";
            }
            pausar();
        }

    } while (op != 0);
}

// ════════════════════════════════════════════════════════════════
//  MÓDULO 3: Cola de Solicitudes en espera (FIFO)
// ════════════════════════════════════════════════════════════════
void menuCola() {
    int op;
    do {
        encabezado("MODULO 3 — COLA DE SOLICITUDES EN ESPERA");
        cout << "  Solicitudes en espera: " << cola.getCantidad() << "\n";
        separador();
        cout << "  1. Ver todas las solicitudes en cola\n";
        cout << "  2. Atender siguiente solicitud (desencolar)\n";
        cout << "  3. Ver la proxima solicitud (sin desencolar)\n";
        cout << "  0. Volver\n";
        separador();
        op = leerEntero("Opcion: ", 0, 3);

        if (op == 1) {
            encabezado("SOLICITUDES EN ESPERA");
            cola.listarTodas();
            pausar();

        } else if (op == 2) {
            encabezado("ATENDER SIGUIENTE SOLICITUD");
            Solicitud s;
            if (cola.desencolar(s)) {
                cout << "  Atendiendo solicitud:\n";
                s.mostrar();
                // Verificar disponibilidad del proyector
                Proyector* p = inventario.buscar(s.codigoProyector);
                if (p != nullptr && p->estado == DISPONIBLE &&
                    p->horasLampara < LIMITE_HORAS_LAMPARA) {
                    reservas.insertar(Reserva(s.codigoProyector, s.docente,
                                             "2025-06-15", "00:00"));
                    inventario.modificarEstado(s.codigoProyector, PRESTADO);
                    registrarAccion("Solicitud de " + s.docente + " atendida para " +
                                   s.codigoProyector, s.docente);
                    cout << "  [OK] Proyector asignado al docente " << s.docente << "\n";
                } else {
                    cout << "  [!] El proyector no esta disponible aun. "
                         << "Solicitud descartada.\n";
                }
            } else {
                cout << "  [!] No hay solicitudes en la cola.\n";
            }
            pausar();

        } else if (op == 3) {
            encabezado("PROXIMA SOLICITUD");
            cola.verFrente();
            pausar();
        }

    } while (op != 0);
}

// ════════════════════════════════════════════════════════════════
//  MÓDULO 4: Historial (Lista Doblemente Enlazada)
// ════════════════════════════════════════════════════════════════
void menuHistorial() {
    int op;
    do {
        encabezado("MODULO 4 — HISTORIAL DE ACCIONES");
        cout << "  Total de registros: " << historial.getCantidad() << "\n";
        separador();
        cout << "  1. Ver historial completo\n";
        cout << "  2. Ver registro actual\n";
        cout << "  3. Navegar hacia adelante\n";
        cout << "  4. Navegar hacia atras\n";
        cout << "  0. Volver\n";
        separador();
        op = leerEntero("Opcion: ", 0, 4);

        if (op == 1) {
            encabezado("HISTORIAL COMPLETO");
            historial.mostrarTodo();
            pausar();
        } else if (op == 2) {
            historial.mostrarActual();
            pausar();
        } else if (op == 3) {
            historial.navegarAdelante();
            pausar();
        } else if (op == 4) {
            historial.navegarAtras();
            pausar();
        }

    } while (op != 0);
}

// ════════════════════════════════════════════════════════════════
//  MÓDULO 5: Turnos Circulares (Lista Circular)
// ════════════════════════════════════════════════════════════════
void menuTurnos() {
    int op;
    do {
        encabezado("MODULO 5 — TURNOS CIRCULARES DE EXPOSITORES");
        cout << "  Expositores en ronda: " << turnos.getCantidad() << "\n";
        separador();
        cout << "  1. Ver ronda completa\n";
        cout << "  2. Ver turno actual\n";
        cout << "  3. Avanzar al siguiente turno\n";
        cout << "  4. Agregar expositor a la ronda\n";
        cout << "  5. Eliminar expositor actual\n";
        cout << "  0. Volver\n";
        separador();
        op = leerEntero("Opcion: ", 0, 5);

        if (op == 1) {
            encabezado("RONDA ACTUAL DE EXPOSITORES");
            turnos.mostrarRonda();
            pausar();

        } else if (op == 2) {
            turnos.mostrarActual();
            pausar();

        } else if (op == 3) {
            turnos.avanzarTurno();
            registrarAccion("Turno avanzado en evento", "Sistema");
            pausar();

        } else if (op == 4) {
            encabezado("AGREGAR EXPOSITOR");
            limpiarBuffer();
            string nom  = leerCadena("Nombre del expositor: ");
            string tema = leerCadena("Tema de exposicion: ");
            turnos.insertar(Expositor(nom, tema));
            registrarAccion("Expositor " + nom + " agregado a la ronda", "Admin");
            cout << "  [OK] Expositor agregado a la ronda circular.\n";
            pausar();

        } else if (op == 5) {
            turnos.eliminarActual();
            registrarAccion("Expositor eliminado de la ronda", "Admin");
            pausar();
        }

    } while (op != 0);
}

// ════════════════════════════════════════════════════════════════
//  MÓDULO 6: Mantenimiento + Deshacer (Pila LIFO)
// ════════════════════════════════════════════════════════════════
void menuMantenimiento() {
    int op;
    do {
        encabezado("MODULO 6 — MANTENIMIENTO Y DESHACER");
        cout << "  Acciones reversibles en pila: " << pila.getCantidad() << "\n";
        separador();
        cout << "  1. Enviar proyector a mantenimiento\n";
        cout << "  2. Ver ultima accion reversible (tope de pila)\n";
        cout << "  3. Deshacer ultima accion\n";
        cout << "  4. Ver proyectores en mantenimiento\n";
        cout << "  0. Volver\n";
        separador();
        op = leerEntero("Opcion: ", 0, 4);

        if (op == 1) {
            encabezado("ENVIAR A MANTENIMIENTO");
            limpiarBuffer();
            string cod = leerCadena("Codigo del proyector: ");
            Proyector* p = inventario.buscar(cod);
            if (p == nullptr) {
                cout << "  [!] Proyector no encontrado.\n";
            } else if (p->estado == MANTENIMIENTO) {
                cout << "  [!] El proyector ya esta en mantenimiento.\n";
            } else if (reservas.estaReservado(cod)) {
                cout << "  [!] El proyector tiene una reserva activa. Procese la devolucion primero.\n";
            } else {
                EstadoProyector anterior = p->estado;
                // Guardar en pila ANTES de cambiar
                pila.apilar("Proyector " + cod + " enviado a mantenimiento",
                            cod, anterior);
                inventario.modificarEstado(cod, MANTENIMIENTO);
                registrarAccion("Proyector " + cod + " enviado a mantenimiento", "Admin");
                cout << "  [OK] Proyector en mantenimiento. "
                     << "Accion guardada. Puede deshacerse con la opcion 3.\n";
            }
            pausar();

        } else if (op == 2) {
            encabezado("TOPE DE PILA — ULTIMA ACCION REVERSIBLE");
            pila.verTope();
            pausar();

        } else if (op == 3) {
            encabezado("DESHACER ULTIMA ACCION");
            string desc, cod;
            EstadoProyector estadoAnterior;
            if (pila.desapilar(desc, cod, estadoAnterior)) {
                inventario.modificarEstado(cod, estadoAnterior);
                registrarAccion("DESHACER: " + desc + " → restaurado a " +
                               estadoATexto(estadoAnterior), "Admin");
                cout << "  [OK] Accion deshecha: " << desc << "\n";
                cout << "  Proyector " << cod << " restaurado a: "
                     << estadoATexto(estadoAnterior) << "\n";
            } else {
                cout << "  [!] No hay acciones para deshacer.\n";
            }
            pausar();

        } else if (op == 4) {
            encabezado("PROYECTORES EN MANTENIMIENTO");
            bool hay = false;
            for (int i = 0; i < inventario.getCantidad(); i++) {
                Proyector* p = inventario.getProyector(i);
                if (p != nullptr && p->estado == MANTENIMIENTO) {
                    p->mostrar();
                    separador();
                    hay = true;
                }
            }
            if (!hay) cout << "  Ningun proyector en mantenimiento actualmente.\n";
            pausar();
        }

    } while (op != 0);
}

// ════════════════════════════════════════════════════════════════
//  MENÚ PRINCIPAL
// ════════════════════════════════════════════════════════════════
void menuPrincipal() {
    int op;
    do {
        encabezado("SMARTCAMPUS UTA — SISTEMA DE PROYECTORES | GRUPO B");
        cout << "  1. Inventario de proyectores     (Lista secuencial)\n";
        cout << "  2. Reservas activas              (Lista simplemente enlazada)\n";
        cout << "  3. Cola de espera                (Cola FIFO)\n";
        cout << "  4. Historial de acciones         (Lista doblemente enlazada)\n";
        cout << "  5. Turnos de expositores         (Lista circular)\n";
        cout << "  6. Mantenimiento y deshacer      (Pila LIFO)\n";
        cout << "  0. Salir\n";
        separador();
        cout << "  Proyectores: " << inventario.getCantidad()
             << " | Reservas: "  << reservas.getCantidad()
             << " | Cola: "      << cola.getCantidad()
             << " | Historial: " << historial.getCantidad()
             << " | Turnos: "    << turnos.getCantidad()
             << " | Pila: "      << pila.getCantidad() << "\n";
        separador();
        op = leerEntero("Opcion: ", 0, 6);

        switch (op) {
            case 1: menuInventario();    break;
            case 2: menuReservas();      break;
            case 3: menuCola();          break;
            case 4: menuHistorial();     break;
            case 5: menuTurnos();        break;
            case 6: menuMantenimiento(); break;
            case 0:
                cout << "\n  Hasta luego. Sistema cerrado correctamente.\n\n";
                break;
        }
    } while (op != 0);
}

// ════════════════════════════════════════════════════════════════
//  PUNTO DE ENTRADA
// ════════════════════════════════════════════════════════════════
int main() {
    cout << "\n" << string(60, '=') << "\n";
    cout << "   SmartCampus UTA — Sistema de Proyectores\n";
    cout << "   Grupo B | Estructura de Datos | C++17\n";
    cout << string(60, '=') << "\n\n";

    cout << "  Cargando datos de prueba...\n";
    cargarDatosPrueba();
    pausar();

    menuPrincipal();
    return 0;
}
